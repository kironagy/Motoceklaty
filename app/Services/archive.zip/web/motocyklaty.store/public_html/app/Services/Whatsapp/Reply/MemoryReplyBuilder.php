<?php

namespace App\Services\Whatsapp\Reply;

use App\Services\AiMemoryResolver;
use App\Services\AiReplyBuilder;
use Illuminate\Support\Collection;

class MemoryReplyBuilder
{
    public function render(string $title, array $variables = []): ?string
    {
        if (! class_exists(AiMemoryResolver::class)) {
            return null;
        }

        $memory = app(AiMemoryResolver::class)->memoryByExactTitle($title);

        if (! $memory) {
            return null;
        }

        $reply = app(AiReplyBuilder::class)
            ->fromMemories(collect([$memory]), $variables, '');

        $reply = trim((string) $reply);

        return $reply !== '' ? $reply : null;
    }

    public function renderOrDefault(string $title, array $variables, string $default): string
    {
        return $this->render($title, $variables) ?: $default;
    }
}