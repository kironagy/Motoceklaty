<?php

namespace App\Services\Whatsapp\Search;

use App\Models\Brand;
use App\Models\Machine;
use Illuminate\Support\Collection;

class MachineFilter
{
    public function byRequestedBrand(Collection $machines, string $message, callable $normalize): array
    {
        $requestedBrand = $this->extractRequestedBrand($message, $normalize);

        if (! $requestedBrand) {
            return [
                'brand_requested' => false,
                'machines' => $machines,
            ];
        }

        return [
            'brand_requested' => true,
            'brand_id' => $requestedBrand['id'],
            'brand_name' => $requestedBrand['name'],
            'machines' => $machines
                ->filter(fn (Machine $m) => (int) $m->brand_id === (int) $requestedBrand['id'])
                ->values(),
            'original_machines' => $machines,
        ];
    }

    public function byRequiredNumbers(Collection $machines, string $message, callable $normalize): Collection
    {
        preg_match_all('/\d+/u', $normalize($message), $matches);
        $numbers = array_values(array_unique($matches[0] ?? []));

        if (empty($numbers) || $machines->count() <= 1) {
            return $machines;
        }

        $filtered = $machines->filter(function (Machine $machine) use ($numbers, $normalize) {
            $name = $normalize((string) $machine->name);

            foreach ($numbers as $number) {
                if (! preg_match('/(?:^|\D)' . preg_quote($number, '/') . '(?:\D|$)/u', $name)) {
                    return false;
                }
            }

            return true;
        })->values();

        return $filtered->isNotEmpty() ? $filtered : $machines;
    }

    public function narrowByVariant(Collection $machines, string $message, callable $normalize): Collection
    {
        $m = $normalize($message);

        if ($machines->count() <= 1) {
            return $machines;
        }

        if (str_contains($m, 'فرز تاني') || str_contains($m, 'فرز ثاني')) {
            $filtered = $machines->filter(fn ($machine) =>
                str_contains($normalize($machine->name), 'فرز تاني')
                || str_contains($normalize($machine->name), 'فرز ثاني')
            )->values();

            return $filtered->isNotEmpty() ? $filtered : $machines;
        }

        if (str_contains($m, 'استيراد')) {
            $filtered = $machines->filter(function ($machine) use ($normalize) {
                $name = $normalize($machine->name);

                return str_contains($name, 'استيراد')
                    && ! str_contains($name, 'فرز تاني')
                    && ! str_contains($name, 'فرز ثاني');
            })->values();

            return $filtered->isNotEmpty() ? $filtered : $machines;
        }

        return $machines;
    }

    private function extractRequestedBrand(string $message, callable $normalize): ?array
    {
        $m = $normalize($message);

        foreach (Brand::all() as $brand) {
            $name = trim((string) $brand->name);

            if ($name !== '' && str_contains($m, $normalize($name))) {
                return ['id' => $brand->id, 'name' => $name];
            }
        }

        return null;
    }
}