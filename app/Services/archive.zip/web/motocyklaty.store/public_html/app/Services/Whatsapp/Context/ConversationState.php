<?php

namespace App\Services\Whatsapp\Context;

use App\Models\WhatsappConversation;

class ConversationState
{
    public function update(
        WhatsappConversation $conversation,
        ?string $topic = null,
        ?string $pendingQuestion = null,
        array $payload = []
    ): void {
        $conversation->forceFill([
            'last_topic' => $topic,
            'pending_question' => $pendingQuestion,
            'context_payload' => $payload ?: null,
        ])->save();
    }

    public function mergePayload(WhatsappConversation $conversation, array $payload): void
    {
        $current = is_array($conversation->context_payload)
            ? $conversation->context_payload
            : [];

        $conversation->forceFill([
            'context_payload' => array_replace_recursive($current, $payload),
        ])->save();
    }
}