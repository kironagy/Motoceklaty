<?php

namespace App\Services\Whatsapp\Context;

use App\Models\Machine;
use App\Models\WhatsappConversation;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;

class ConversationMemory
{
    public function rememberMachines(WhatsappConversation $conversation, Collection $machines): void
    {
        if ($machines->isEmpty()) {
            return;
        }

        $data = [
            'last_machine_id' => $machines->first()?->id,
            'last_machine_ids' => $machines->pluck('id')->values()->all(),
        ];

        $allowed = [];

        foreach ($data as $key => $value) {
            if (Schema::hasColumn('whatsapp_conversations', $key)) {
                $allowed[$key] = $value;
            }
        }

        if ($allowed) {
            $conversation->forceFill($allowed)->save();
        }
    }

    public function lastMachines(WhatsappConversation $conversation): Collection
    {
        if (! Schema::hasColumn('whatsapp_conversations', 'last_machine_ids')) {
            return collect();
        }

        $ids = $conversation->last_machine_ids ?? [];

        if (is_string($ids)) {
            $ids = json_decode($ids, true) ?: [];
        }

        if (! is_array($ids) || ! count($ids)) {
            return collect();
        }

        return Machine::query()
            ->with('brand')
            ->whereIn('id', $ids)
            ->get()
            ->sortBy(fn ($machine) => array_search($machine->id, $ids, true))
            ->values();
    }
}