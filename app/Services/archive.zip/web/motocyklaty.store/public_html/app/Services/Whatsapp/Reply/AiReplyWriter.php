<?php

namespace App\Services\Whatsapp\Reply;

use App\Services\GeminiClient;
use Illuminate\Support\Facades\Log;

class AiReplyWriter
{
    public function write(string $purpose, array $facts, string $fallback): string
    {
        $prompt = <<<PROMPT
أنت كاتب ردود واتساب لمعرض موتوسيكلات في مصر.

مهمتك صياغة الرد فقط، وليس اتخاذ قرار.

ممنوع:
- تضيف أسعار أو شروط أو بيانات غير موجودة في facts.
- تطلب بيانات موجودة بالفعل.
- تغير معنى الرد.
- تقول معلومات من عندك.
- تطول في الكلام.

اكتب بالمصري المهذب، رد قصير وواضح ومقنع.

purpose:
{$purpose}

facts:
PROMPT;

        try {
            $result = app(GeminiClient::class)->generateText(
                $prompt . "\n" . json_encode($facts, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                null,
                [
                    'temperature' => 0.3,
                    'max_output_tokens' => 450,
                ]
            );

            $reply = trim((string) ($result['text'] ?? ''));

            if ($reply === '') {
                return $fallback;
            }

            $reply = preg_replace('/^```.*$/m', '', $reply);
            $reply = str_replace('```', '', $reply);
            $reply = trim($reply);

            return $reply !== '' ? $reply : $fallback;
        } catch (\Throwable $e) {
            Log::warning('AI reply writer failed', [
                'purpose' => $purpose,
                'error' => $e->getMessage(),
            ]);

            return $fallback;
        }
    }
}