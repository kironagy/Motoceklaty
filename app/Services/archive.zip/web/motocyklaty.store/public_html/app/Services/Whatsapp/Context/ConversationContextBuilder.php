<?php

namespace App\Services\Whatsapp\Context;

use App\Models\Machine;
use App\Models\WhatsappConversation;

class ConversationContextBuilder
{
    public function build(WhatsappConversation $conversation, string $message): array
    {
        $lastMachines = app(ConversationMemory::class)
            ->lastMachines($conversation)
            ->map(fn (Machine $machine) => [
                'id' => $machine->id,
                'name' => $machine->name,
                'brand' => $machine->brand?->name,
                'cash_price' => $machine->cash_price,
                'installment_price' => $machine->installment_price,
            ])
            ->values()
            ->all();

        return [
            'conversation_id' => $conversation->id,
            'current_message' => $message,
            'last_topic' => $conversation->last_topic ?? null,
            'pending_question' => $conversation->pending_question ?? null,
            'context_payload' => $conversation->context_payload ?? [],
            'last_machine_id' => $conversation->last_machine_id ?? null,
            'last_machine_ids' => $conversation->last_machine_ids ?? [],
            'last_machines' => $lastMachines,
            'recent_messages' => $conversation->messages()
                ->latest()
                ->take(12)
                ->get()
                ->reverse()
                ->map(fn ($m) => [
                    'direction' => $m->direction,
                    'message' => $m->message,
                ])
                ->values()
                ->all(),
        ];
    }
}