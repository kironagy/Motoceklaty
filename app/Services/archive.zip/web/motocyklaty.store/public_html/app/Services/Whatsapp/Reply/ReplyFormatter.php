<?php

namespace App\Services\Whatsapp\Reply;

class ReplyFormatter
{
    public function textResult(string $reply, array $extra = []): array
    {
        return array_merge([
            'handled' => true,
            'type' => 'text',
            'reply' => $reply,
            'image' => null,
            'images' => [],
            'image_items' => [],
            'image_groups' => [],
        ], $extra);
    }

    public function emptyResult(string $reason = 'not_handled', array $extra = []): array
    {
        return array_merge([
            'handled' => false,
            'type' => 'none',
            'reason' => $reason,
            'reply' => null,
            'image' => null,
            'images' => [],
            'image_items' => [],
            'image_groups' => [],
        ], $extra);
    }
}