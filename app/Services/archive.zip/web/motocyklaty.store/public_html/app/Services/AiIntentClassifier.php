<?php

namespace App\Services;

use App\Models\WhatsappConversation;
use Illuminate\Support\Facades\Log;

class AiIntentClassifier
{
    public function classify(WhatsappConversation $conversation, string $message, array $context = []): array
    {
        $recent = $conversation->messages()
            ->latest()
            ->take(12)
            ->get()
            ->reverse()
            ->map(fn ($m) => [
                'direction' => $m->direction,
                'message' => $m->message,
            ])
            ->values()
            ->all();

        $prompt = $this->prompt($conversation, $message, $recent, $context);

        try {
            $result = app(GeminiClient::class)->generateText($prompt, null, [
                'temperature' => 0.1,
                'max_output_tokens' => 600,
            ]);

            $text = trim((string) ($result['text'] ?? ''));

            $json = $this->extractJson($text);

            if (! is_array($json)) {
                return $this->fallback();
            }

            return array_merge($this->fallback(), $json);
        } catch (\Throwable $e) {
            Log::error('AI intent classifier failed', [
                'message' => $e->getMessage(),
            ]);

            return $this->fallback();
        }
    }

    private function prompt(
        WhatsappConversation $conversation,
        string $message,
        array $recent,
        array $context
    ): string {
        $payload = [
            'current_message' => $message,
            'conversation_state' => [
                'last_machine_id' => $conversation->last_machine_id ?? null,
                'last_machine_ids' => $conversation->last_machine_ids ?? [],
                'last_topic' => $conversation->last_topic ?? null,
                'pending_question' => $conversation->pending_question ?? null,
                'context_payload' => $conversation->context_payload ?? [],
            ],
            'recent_messages' => $recent,
            'known_context' => $context,
        ];

        return <<<PROMPT
أنت مصنف نوايا فقط لبوت واتساب معرض موتوسيكلات.

ممنوع تكتب رد للعميل.
ممنوع تشرح.
لازم ترجع JSON فقط.

النوايا المتاحة:
- price
- images
- installment_calc
- installment_system
- brand_models
- general
- unknown

قواعد مهمة:
- لو العميل يقصد آخر مكنة اتكلم عنها بكلام زي: دي، ده، دول، الاتنين، صورهم، صورتها، احسبهالي، عليها سنة، سنتين، كام قسط = target يكون last_machines.
- لو العميل بيسأل عن أنظمة أو شروط التقسيط = installment_system.
- لو العميل عايز يحسب قسط أو قال مدة تقسيط = installment_calc.
- لو العميل عايز صور أو شكل أو ألوان = images.
- لو العميل بيسأل سعر أو بكام = price.
- لو ذكر موديل جديد، حط الكلام المناسب في machine_query.
- لو العميل رد على سؤال مدة التقسيط فقط، استخرج months.
- سنة = 12
- سنة ونص = 18
- سنتين = 24
- 3 سنين = 36

رجع JSON بالشكل ده فقط:

{
  "intent": "unknown",
  "target": "unknown",
  "machine_query": null,
  "uses_last_machines": false,
  "months": null,
  "deposit": null,
  "deposit_mentioned": false,
  "system": null,
  "needs_machine": false,
  "needs_months": false,
  "confidence": 0.0
}

target:
- last_machines
- new_machine
- unknown

system:
- "20"
- "30"
- null

البيانات:
PROMPT
        . "\n" . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }

    private function fallback(): array
    {
        return [
            'intent' => 'unknown',
            'target' => 'unknown',
            'machine_query' => null,
            'uses_last_machines' => false,
            'months' => null,
            'deposit' => null,
            'deposit_mentioned' => false,
            'system' => null,
            'needs_machine' => false,
            'needs_months' => false,
            'confidence' => 0.0,
        ];
    }

    private function extractJson(string $text): ?array
    {
        $text = trim($text);

        $text = preg_replace('/^```json\s*/i', '', $text);
        $text = preg_replace('/^```\s*/i', '', $text);
        $text = preg_replace('/\s*```$/', '', $text);

        if (preg_match('/\{.*\}/su', $text, $m)) {
            $text = $m[0];
        }

        $data = json_decode($text, true);

        return is_array($data) ? $data : null;
    }
}