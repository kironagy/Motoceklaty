<?php

namespace App\Services\Whatsapp\Handlers;

use App\Models\WhatsappConversation;
use App\Services\AiMemoryResolver;
use App\Services\GeminiClient;
use Illuminate\Support\Facades\Log;

class ApplicationHandler
{
    public function handle(WhatsappConversation $conversation, string $message): array
    {
        $conversation->refresh();

        $state = is_array($conversation->context_payload) ? $conversation->context_payload : [];
        $application = is_array($state['application'] ?? null) ? $state['application'] : [];

        $memoryText = $this->applicationMemory();

        $extracted = $this->extractApplicationData($conversation, $message, $memoryText, $application);

        foreach ($extracted as $key => $value) {
            if ($value !== null && $value !== '') {
                $application[$key] = $value;
            }
        }

        $requirements = $this->requirementsForJobType($message, $memoryText, $application['job_type'] ?? null);

        if (! empty($requirements['job_type']) && $requirements['job_type'] !== 'unknown') {
            $application['job_type'] = $requirements['job_type'];
        }

        $missing = $this->missingFields($application, $requirements['required_fields'] ?? []);

        $state['application'] = $application;

        $conversation->forceFill([
            'last_topic' => 'application',
            'pending_question' => count($missing) ? 'application_missing_fields' : 'application_ready',
            'context_payload' => $state,
        ])->save();

        $reply = count($missing)
            ? $this->buildMissingReply($missing, $requirements)
            : $this->buildReadyReply($application);

        $conversation->messages()->create([
            'direction' => 'outgoing',
            'message' => $reply,
            'payload' => [
                'source' => 'application_handler',
                'application' => $application,
                'missing' => $missing,
                'requirements' => $requirements,
            ],
        ]);

        return [
            'handled' => true,
            'type' => 'text',
            'reply' => $reply,
            'image' => null,
            'images' => [],
            'image_items' => [],
            'image_groups' => [],
        ];
    }

    private function applicationMemory(): string
    {
        foreach (['بيانات التقديم', 'شروط وبيانات التقديم', 'مستندات التقديم', 'رد نظام التقسيط'] as $title) {
            try {
                $memory = app(AiMemoryResolver::class)->memoryByExactTitle($title);

                if ($memory) {
                    return (string) ($memory->content ?? $memory->body ?? $memory->text ?? '');
                }
            } catch (\Throwable $e) {
                Log::warning('application memory failed', ['error' => $e->getMessage()]);
            }
        }

        return '';
    }

    private function extractApplicationData(
        WhatsappConversation $conversation,
        string $message,
        string $memoryText,
        array $currentApplication
    ): array {
        $payload = [
            'current_application' => $currentApplication,
            'current_message' => $message,
            'recent_messages' => $conversation->messages()
                ->latest()
                ->take(10)
                ->get()
                ->reverse()
                ->map(fn ($m) => [
                    'direction' => $m->direction,
                    'message' => $m->message,
                ])
                ->values()
                ->all(),
        ];

        $prompt = <<<PROMPT
أنت مستخرج بيانات فقط من رسالة عميل يريد تقديم تقسيط موتوسيكل.

ممنوع ترد على العميل.
رجع JSON فقط.

استخرج أي بيانات موجودة في الرسالة الحالية أو السياق.

الحقول:
{
  "customer_name": null,
  "machine_query": null,
  "job_type": null,
  "company_name": null,
  "activity_type": null,
  "monthly_income": null,
  "months": null,
  "deposit": null,
  "phone": null,
  "notes": null
}

job_type:
employee, business_owner, freelancer, pensioner, delivery_driver, unknown

موظف/شركة/إداري/محاسب = employee
صاحب محل/معرض/نشاط/سجل تجاري = business_owner
شغل حر/فريلانسر/مهني حر = freelancer
معاش = pensioner
دليفري/طلبات/اندرايف/اوبر/سائق = delivery_driver

سنة = 12
سنة ونص = 18
سنتين = 24
3 سنين = 36

ميموري التقديم:
{$memoryText}

البيانات:
PROMPT;

        try {
            $result = app(GeminiClient::class)->generateText(
                $prompt . "\n" . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                null,
                ['temperature' => 0.1, 'max_output_tokens' => 700]
            );

            return $this->extractJson((string) ($result['text'] ?? '')) ?: [];
        } catch (\Throwable $e) {
            Log::error('application extract failed', ['error' => $e->getMessage()]);
            return [];
        }
    }

    private function requirementsForJobType(string $message, string $memoryText, ?string $jobType): array
    {
        $prompt = <<<PROMPT
أنت تستخرج متطلبات التقديم من ميموري معرض موتوسيكلات.

ممنوع ترد على العميل.
رجع JSON فقط.

job_type الحالي:
{$jobType}

رسالة العميل:
{$message}

الميموري:
{$memoryText}

رجع JSON:
{
  "job_type": "unknown",
  "required_fields": [],
  "documents": [],
  "notes": null
}

استخدم فقط المطلوب الموجود في الميموري حسب نوع الحالة.
لو الميموري غير واضحة، استخدم:
customer_name, machine_query, job_type, months
PROMPT;

        try {
            $result = app(GeminiClient::class)->generateText(
                $prompt,
                null,
                ['temperature' => 0.1, 'max_output_tokens' => 700]
            );

            $json = $this->extractJson((string) ($result['text'] ?? ''));

            if (is_array($json)) {
                return [
                    'job_type' => $json['job_type'] ?? ($jobType ?: 'unknown'),
                    'required_fields' => array_values(array_unique(array_filter($json['required_fields'] ?? []))),
                    'documents' => array_values(array_unique(array_filter($json['documents'] ?? []))),
                    'notes' => $json['notes'] ?? null,
                ];
            }
        } catch (\Throwable $e) {
            Log::error('application requirements failed', ['error' => $e->getMessage()]);
        }

        return [
            'job_type' => $jobType ?: 'unknown',
            'required_fields' => ['customer_name', 'machine_query', 'job_type', 'months'],
            'documents' => [],
            'notes' => null,
        ];
    }

    private function missingFields(array $application, array $requiredFields): array
    {
        $labels = [
            'customer_name' => 'اسمك بالكامل',
            'machine_query' => 'المكنة اللي عايز تقدم عليها',
            'job_type' => 'طبيعة شغلك',
            'company_name' => 'اسم الشركة أو جهة العمل',
            'activity_type' => 'نوع النشاط',
            'monthly_income' => 'الدخل الشهري',
            'months' => 'مدة التقسيط',
            'deposit' => 'المقدم',
            'phone' => 'رقم الموبايل',
        ];

        $missing = [];

        foreach ($requiredFields as $field) {
            if (isset($labels[$field]) && empty($application[$field])) {
                $missing[$field] = $labels[$field];
            }
        }

        return $missing;
    }

    private function buildMissingReply(array $missing, array $requirements): string
    {
        $lines = ['تمام يا فندم، محتاج منك الناقص بس عشان نكمل التقديم:'];

        foreach ($missing as $label) {
            $lines[] = '- ' . $label;
        }

        if (! empty($requirements['documents'])) {
            $lines[] = '';
            $lines[] = 'والمستندات المطلوبة لحالتك:';

            foreach ($requirements['documents'] as $doc) {
                $lines[] = '- ' . $doc;
            }
        }

        return implode("\n", $lines);
    }

    private function buildReadyReply(array $application): string
    {
        return "تمام يا فندم، بيانات التقديم الأساسية موجودة عندي.\nهراجعها ونكمل إجراءات التقديم.";
    }

    private function extractJson(string $text): ?array
    {
        $text = trim($text);
        $text = preg_replace('/^```json\s*/i', '', $text);
        $text = preg_replace('/^```\s*/i', '', $text);
        $text = preg_replace('/\s*```$/', '', $text);

        if (preg_match('/\{.*\}/su', $text, $m)) {
            $text = $m[0];
        }

        $data = json_decode($text, true);

        return is_array($data) ? $data : null;
    }
}