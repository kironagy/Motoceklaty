<?php

namespace App\Services\Whatsapp\Search;

use App\Models\Machine;

class MachinePresenter
{
    public function displayName(Machine $machine): string
    {
        $brand = $this->brandName($machine);
        $name = trim((string) $machine->name);

        if ($brand !== '' && ! str_contains(mb_strtolower($name), mb_strtolower($brand))) {
            return $brand . ' ' . $name;
        }

        return $name;
    }

    public function brandName(Machine $machine): string
    {
        if (method_exists($machine, 'brand')) {
            return trim((string) ($machine->brand?->name ?? ''));
        }

        return '';
    }
}