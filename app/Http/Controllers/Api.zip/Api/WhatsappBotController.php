<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Machine;
use App\Models\WhatsappBot;
use App\Models\WhatsappConversation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class WhatsappBotController extends Controller
{
    public function incomingMessage(Request $request)
    {
        if ($request->header('X-BOT-TOKEN') !== env('BOT_TOKEN')) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $botId = $request->input('bot_id');
        $from = $request->input('from');
        $message = trim($request->input('message', ''));

        if (!$from || !$message) {
            return response()->json([
                'reply' => null,
                'image' => null,
            ]);
        }

        $phone = str_replace('@s.whatsapp.net', '', $from);

        $bot = WhatsappBot::find($botId);

        $conversation = WhatsappConversation::firstOrCreate(
            [
                'whatsapp_bot_id' => $bot?->id,
                'phone' => $phone,
            ],
            [
                'status' => 'open',
            ]
        );

        $conversation->messages()->create([
            'direction' => 'incoming',
            'message' => $message,
            'payload' => $request->all(),
        ]);

        $machine = $this->findMachine($message);

        if ($machine) {
            $conversation->update([
                'last_machine_id' => $machine->id,
            ]);

            $reply = $this->machinePriceReply($machine);

            $conversation->messages()->create([
                'direction' => 'outgoing',
                'message' => $reply,
            ]);

            return response()->json([
                'reply' => $reply,
                'image' => null,
            ]);
        }

        if ($this->isAskingForImage($message) && $conversation->lastMachine) {
            $image = $this->machineImageUrl($conversation->lastMachine);

            $reply = 'اتفضل يا فندم، دي صورة ' . $conversation->lastMachine->name;

            $conversation->messages()->create([
                'direction' => 'outgoing',
                'message' => $reply,
                'payload' => [
                    'image' => $image,
                ],
            ]);

            return response()->json([
                'reply' => $reply,
                'image' => $image,
            ]);
        }

        $reply = 'تمام يا فندم، ممكن تقولي اسم المكنة اللي حضرتك بتسأل عليها؟';

        $conversation->messages()->create([
            'direction' => 'outgoing',
            'message' => $reply,
        ]);

        return response()->json([
            'reply' => $reply,
            'image' => null,
        ]);
    }

    private function findMachine(string $message): ?Machine
    {
        $message = trim($message);

        $machines = Machine::query()
            ->select('id', 'name', 'cash_price', 'installment_price', 'display_image')
            ->get();

        $normalizedMessage = $this->normalizeArabic($message);

        foreach ($machines as $machine) {
            $machineName = $this->normalizeArabic($machine->name);

            if (Str::contains($normalizedMessage, $machineName)) {
                return $machine;
            }

            similar_text($normalizedMessage, $machineName, $percent);

            if ($percent >= 55) {
                return $machine;
            }
        }

        return null;
    }

    private function machinePriceReply(Machine $machine): string
    {
        $cash = number_format((float) $machine->cash_price);
        $installment = number_format((float) $machine->installment_price);

        return "سعر {$machine->name} كاش {$cash} جنيه يا فندم.\n"
            . "وسعر التقسيط {$installment} جنيه.\n"
            . "تحب أبعتلك صورتها؟";
    }

    private function isAskingForImage(string $message): bool
    {
        $message = $this->normalizeArabic($message);

        return Str::contains($message, [
            'صوره',
            'صورة',
            'شكل',
            'اشوفها',
            'ابعت',
            'صورتها',
        ]);
    }

    private function machineImageUrl(Machine $machine): ?string
    {
        if (!$machine->display_image) {
            return null;
        }

        return url(Storage::url($machine->display_image));
    }

    private function normalizeArabic(string $text): string
    {
        $text = mb_strtolower($text);
        $text = str_replace(['أ', 'إ', 'آ'], 'ا', $text);
        $text = str_replace(['ة'], 'ه', $text);
        $text = str_replace(['ى'], 'ي', $text);
        $text = str_replace(['ؤ'], 'و', $text);
        $text = str_replace(['ئ'], 'ي', $text);
        $text = preg_replace('/[^\p{Arabic}a-zA-Z0-9\s]/u', ' ', $text);
        $text = preg_replace('/\s+/', ' ', $text);

        return trim($text);
    }
}