const makeWASocket = require('@whiskeysockets/baileys').default;
const {
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion
} = require('@whiskeysockets/baileys');

const pino = require('pino');
const axios = require('axios');
const express = require('express');
const QRCode = require('qrcode');
require('dotenv').config();

const app = express();
app.use(express.json());

const sessions = {};
const latestQr = {};
const statuses = {};
const starting = {};
const handledMessages = new Set();

function checkToken(req, res, next) {
    const token = req.headers['x-bot-token'];
    if (token !== process.env.BOT_TOKEN) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    next();
}

function normalizeBotId(botId) {
    return String(botId || '').replace(/[^a-zA-Z0-9_-]/g, '');
}

function normalizeJid(jid) {
    if (!jid) return jid;

    if (jid === 'status@broadcast' || jid.endsWith('@g.us')) {
        return jid;
    }

    // مهم جدًا:
    // لو جاي @lid سيبه زي ما هو، متحولوش @s.whatsapp.net
    if (jid.endsWith('@lid')) {
        return jid;
    }

    return jid;
}

function getMessageText(msg) {
    return (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        msg.message?.imageMessage?.caption ||
        msg.message?.videoMessage?.caption ||
        msg.message?.buttonsResponseMessage?.selectedDisplayText ||
        msg.message?.listResponseMessage?.title ||
        ''
    ).trim();
}

async function sendTextSafely(sock, jid, text) {
    try {
        const safeJid = normalizeJid(jid);
        console.log(`📤 Sending text to ${safeJid}:`, text);
        await sock.sendMessage(safeJid, { text });
        console.log(`✅ Text sent to ${safeJid}`);
        return true;
    } catch (error) {
        console.error('❌ send text error:', error?.message || error);
        return false;
    }
}

async function sendImageSafely(sock, jid, image, caption = '') {
    try {
        const safeJid = normalizeJid(jid);
        console.log(`📤 Sending image to ${safeJid}:`, image);
        await sock.sendMessage(safeJid, {
            image: { url: image },
            caption: caption || ''
        });
        console.log(`✅ Image sent to ${safeJid}`);
        return true;
    } catch (error) {
        console.error('❌ send image error:', error?.message || error);
        return false;
    }
}

async function startSession(botId) {
    botId = normalizeBotId(botId);

    if (!botId) throw new Error('bot_id is required');

    if (starting[botId] || sessions[botId]) return;

    starting[botId] = true;
    statuses[botId] = 'starting';

    const { state, saveCreds } = await useMultiFileAuthState(`./sessions/${botId}`);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        auth: state,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,
        browser: [`Motocyklaty Bot ${botId}`, 'Chrome', '1.0.0'],
        syncFullHistory: false,
        markOnlineOnConnect: false
    });

    sessions[botId] = sock;

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) {
            latestQr[botId] = await QRCode.toDataURL(qr);
            statuses[botId] = 'qr';
            console.log(`📲 QR جاهز للبوت رقم ${botId}`);
        }

        if (connection === 'open') {
            latestQr[botId] = null;
            statuses[botId] = 'connected';
            starting[botId] = false;
            console.log(`✅ Bot ${botId} connected successfully`);
        }

        if (connection === 'close') {
            starting[botId] = false;

            const statusCode = lastDisconnect?.error?.output?.statusCode;
            const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

            delete sessions[botId];
            statuses[botId] = shouldReconnect ? 'disconnected' : 'logged_out';

            console.log(`❌ Bot ${botId} closed. reconnect:`, shouldReconnect);

            if (shouldReconnect) {
                setTimeout(() => {
                    startSession(botId).catch((error) => {
                        console.error(`restart bot ${botId} error:`, error);
                    });
                }, 3000);
            } else {
                latestQr[botId] = null;
            }
        }
    });

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        try {
            if (type !== 'notify') return;

            const msg = messages[0];
            if (!msg || !msg.message || msg.key.fromMe) return;

            const originalFrom = msg.key.remoteJid;
            const replyJid = normalizeJid(originalFrom);

            if (!originalFrom || originalFrom === 'status@broadcast' || originalFrom.endsWith('@g.us')) return;

            const messageId = `${botId}_${msg.key.id}`;
            if (handledMessages.has(messageId)) return;

            handledMessages.add(messageId);

            if (handledMessages.size > 3000) {
                handledMessages.clear();
            }

            const cleanText = getMessageText(msg);
            if (!cleanText) return;

            console.log(`📩 Bot ${botId} رسالة من: ${originalFrom} => ${cleanText}`);
            console.log(`↩️ Reply JID: ${replyJid}`);

            const laravelResponse = await axios.post(process.env.LARAVEL_WEBHOOK_URL, {
                bot_id: botId,
                from: originalFrom,
                reply_jid: replyJid,
                message: cleanText
            }, {
                headers: {
                    'X-BOT-TOKEN': process.env.BOT_TOKEN,
                    'Accept': 'application/json'
                },
                timeout: 20000
            });

            console.log('Laravel response FULL:', JSON.stringify(laravelResponse.data, null, 2));

            const reply = laravelResponse.data?.reply || null;
            const image = laravelResponse.data?.image || null;

            if (image) {
                await sendImageSafely(sock, replyJid, image, reply || '');
                return;
            }

            if (reply) {
                await sendTextSafely(sock, replyJid, reply);
            }
        } catch (error) {
            console.error('❌ ERROR FULL:', {
                message: error.message,
                data: error.response?.data,
                status: error.response?.status
            });
        }
    });
}

app.get('/status', checkToken, (req, res) => {
    res.json({
        ok: true,
        sessions: Object.keys(statuses).map((botId) => ({
            bot_id: botId,
            status: statuses[botId],
            has_qr: !!latestQr[botId],
            connected: statuses[botId] === 'connected'
        }))
    });
});

app.post('/sessions/start', checkToken, async (req, res) => {
    try {
        const botId = normalizeBotId(req.body.bot_id);

        if (!botId) {
            return res.status(422).json({ error: 'bot_id is required' });
        }

        await startSession(botId);

        res.json({
            success: true,
            bot_id: botId,
            status: statuses[botId] || 'starting',
            qr: latestQr[botId] || null
        });
    } catch (error) {
        console.error('sessions/start error:', error);
        res.status(500).json({ error: error.message || 'Start session failed' });
    }
});

app.get('/sessions/:botId/qr', checkToken, (req, res) => {
    const botId = normalizeBotId(req.params.botId);

    res.json({
        bot_id: botId,
        status: statuses[botId] || 'not_started',
        qr: latestQr[botId] || null
    });
});

app.get('/sessions/:botId/status', checkToken, (req, res) => {
    const botId = normalizeBotId(req.params.botId);

    res.json({
        bot_id: botId,
        status: statuses[botId] || 'not_started',
        has_qr: !!latestQr[botId],
        connected: statuses[botId] === 'connected'
    });
});

app.post('/sessions/:botId/send-message', checkToken, async (req, res) => {
    try {
        const botId = normalizeBotId(req.params.botId);
        const sock = sessions[botId];

        if (!sock || statuses[botId] !== 'connected') {
            return res.status(503).json({ error: 'WhatsApp session is not connected' });
        }

        const { phone, message } = req.body;

        if (!phone || !message) {
            return res.status(422).json({ error: 'phone and message are required' });
        }

        const cleanPhone = String(phone).replace(/\D/g, '');
        const jid = cleanPhone + '@s.whatsapp.net';

        const sent = await sendTextSafely(sock, jid, message);

        if (!sent) {
            return res.status(500).json({ error: 'Send failed' });
        }

        res.json({ success: true });
    } catch (error) {
        console.error('send-message error:', error.response?.data || error.message || error);
        res.status(500).json({ error: 'Send failed' });
    }
});

app.post('/sessions/:botId/logout', checkToken, async (req, res) => {
    try {
        const botId = normalizeBotId(req.params.botId);
        const sock = sessions[botId];

        if (sock) {
            await sock.logout();
            delete sessions[botId];
        }

        latestQr[botId] = null;
        statuses[botId] = 'logged_out';

        res.json({ success: true });
    } catch (error) {
        console.error('logout error:', error.response?.data || error.message || error);
        res.status(500).json({ error: 'Logout failed' });
    }
});

const PORT = process.env.PORT || 3010;

app.listen(PORT, () => {
    console.log(`🚀 WhatsApp Multi Sessions API running on port ${PORT}`);
});
