<div>
    {{ $getState() }}
</div>
